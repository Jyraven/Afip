document.addEventListener("DOMContentLoaded", function () {
    const maxFileNameLength = 30;

    const addRowBtn = document.getElementById("addRowBtn");
    const expenseTable = document.getElementById("expenseTable");

    if (addRowBtn && expenseTable) {
        addRowBtn.addEventListener("click", () => {
            const row = expenseTable.querySelector("tr");
            const clone = row.cloneNode(true);

            // Réinitialiser les champs du clone
            clone.querySelectorAll("input, select").forEach(input => {
                if (input.type === "file") {
                    input.value = "";
                } else {
                    input.value = "";
                }
            });

            expenseTable.appendChild(clone);
        });
    }

    document.addEventListener("click", function (e) {
        if (e.target && e.target.classList.contains("removeRowBtn")) {
            const tr = e.target.closest("tr");
            if (tr && expenseTable.rows.length > 1) {
                tr.remove();
            }
        }
    });

    const form = document.querySelector("form");
    if (form) {
        form.addEventListener("submit", function (event) {
            const fileInputs = form.querySelectorAll('input[type="file"]');
            for (const fileInput of fileInputs) {
                const files = fileInput.files;
                for (const file of files) {
                    if (file.name.length > maxFileNameLength) {
                        event.preventDefault();
                        alert(`Le fichier "${file.name}" dépasse ${maxFileNameLength} caractères.`);
                        return;
                    }
                }
            }
        });
    }
});