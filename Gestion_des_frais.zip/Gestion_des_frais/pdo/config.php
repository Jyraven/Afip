<?php
define('DB_HOST', 'localhost');
define('DB_NAME', 'afip_slam1');
define('DB_USER', 'root');
define('DB_PASSWORD', 'root');
