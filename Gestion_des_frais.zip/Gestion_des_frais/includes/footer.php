<footer class="footer-auto bg-blue-100 text-gsb-blue text-center py-4 text-sm font-body shadow-inner">
  <p class="mb-1">&copy; <?= date('Y') ?> GSB - Tous droits réservés.</p>
  <p class="italic">Projet de gestion des frais - AFIP BTS SIO</p>
</footer>